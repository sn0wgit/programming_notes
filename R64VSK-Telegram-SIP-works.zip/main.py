import re
import time
import config
import logging
import asyncio
import datetime
import schedule
from aiogram import Bot, Dispatcher, executor, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from sqlighter import SQLighter
from backend import sutisana

logging.basicConfig(level=logging.INFO)

db = SQLighter('db.db')
bot = Bot(token=config.API_TOKEN)
dp = Dispatcher(bot)

pamatskola = ['button_5' , 'button_6' , 'button_7' , 'button_8', 'button_9']
vidusskola = ['button_10', 'button_11', 'button_12']
burti = ['button_A' ,'button_B' ,'button_C' ,'button_D'  ,'button_E'  ]
grozi = ['button_DA','button_UZ','button_VM','button_DIT','button_DAS','button_INZ','button_VUD','button_VISP']
divas_klases  = []
tris_klases   = []
cetras_klases = ['button_7', 'button_8', 'button_9']
piecas_klases = ['button_5', 'button_6']
klase10 = ['INZ', 'VUD']
klase11 = ['DA', 'DIT', 'UZ', 'VISP']
klase12 = ['DAS', 'DIT', 'UZ', 'VM']

@dp.message_handler(commands=['subscribe'])
async def subscribe(message: types.Message):
  keyboard = InlineKeyboardMarkup()
  button0 = InlineKeyboardButton(text="1.-4. klases", callback_data="button_0")
  button1 = InlineKeyboardButton(text="5. klases", callback_data="button_5")
  button2 = InlineKeyboardButton(text="6. klases", callback_data="button_6")
  button3 = InlineKeyboardButton(text="7. klases", callback_data="button_7")
  button4 = InlineKeyboardButton(text="8. klases", callback_data="button_8")
  button5 = InlineKeyboardButton(text="9. klases", callback_data="button_9")
  button6 = InlineKeyboardButton(text="10. klases", callback_data="button_10")
  button7 = InlineKeyboardButton(text="11. klases", callback_data="button_11")
  button8 = InlineKeyboardButton(text="12. klases", callback_data="button_12")
  keyboard.add(button0, button1, button2, button3, button4, button5, button6, button7, button8)
  await bot.send_message(chat_id=message.chat.id, text="Izvēlaties savu klašu grupu!", reply_markup=keyboard)

@dp.message_handler(commands=['unsubscribe'])
async def unsubscribe(message: types.Message):
  if(not db.subscriber_exists(message.from_user.id)):
    db.add_subscriber(message.from_user.id, 'None', False)
    await message.answer("Jūs jau tāpat nebijāt abonēti.")
  else:
    db.update_status(message.from_user.id, False)
    await message.answer("Jūs esat anulējuši abonementu! Ļoti žēl")
    await message.answer("😢")

numurs = "1337"
klasesb = "KAS"

@dp.callback_query_handler(lambda callback_query: True)
async def process_callback_button(callback_query: types.CallbackQuery):
  data = callback_query.data
  if data in pamatskola or data in vidusskola:
    global numurs
    numurs = data[7:]
    await bot.answer_callback_query(callback_query.id, text=f"Jūs esat izvēlējušies {numurs}. klasi")
  if data == 'button_0': #NO 1. LĪDZ 4. KLASEI NETIEK PUBLICĒTAS STUNDU IZMAIŅAS
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(chat_id=callback_query.message.chat.id, text="Diemžēl, jūsu klasei netiek publicētas stundu izmaiņas skolas mājaslapā, kādēļ mēs nevaram par tām jums ziņot")
    await bot.send_message(chat_id=callback_query.message.chat.id, text="😢")
  elif data in pamatskola: #TUR KUR IR KLAŠU BURTI
    await bot.answer_callback_query(callback_query.id)
    keyboard = InlineKeyboardMarkup()
    buttonA = InlineKeyboardButton(text="A", callback_data="button_A")
    buttonB = InlineKeyboardButton(text="B", callback_data="button_B")
    buttonC = InlineKeyboardButton(text="C", callback_data="button_C")
    buttonD = InlineKeyboardButton(text="D", callback_data="button_D")
    buttonE = InlineKeyboardButton(text="E", callback_data="button_E")
    if data in tris_klases:
      keyboard.add(buttonA, buttonB, buttonC)
    elif data in cetras_klases:
      keyboard.add(buttonA, buttonB)
      keyboard.add(buttonC, buttonD)
    elif data in piecas_klases:
      keyboard.add(buttonA, buttonB, buttonC, buttonD, buttonE)
    await bot.send_message(chat_id=callback_query.message.chat.id, text="Izvēlaties savu klasi!", reply_markup=keyboard)
  elif data in vidusskola: #TUR KUR IR KLAŠU GROZI
    await bot.answer_callback_query(callback_query.id)
    keyboard = InlineKeyboardMarkup(row_width=3)
    buttonDA = InlineKeyboardButton(text="DA", callback_data="button_DA")
    buttonUZ = InlineKeyboardButton(text="UZ", callback_data="button_UZ")
    buttonVM = InlineKeyboardButton(text="VM", callback_data="button_VM")
    buttonDIT = InlineKeyboardButton(text="DIT", callback_data="button_DIT")
    buttonDAS = InlineKeyboardButton(text="DAS", callback_data="button_DAS")
    buttonINZ = InlineKeyboardButton(text="INZ", callback_data="button_INZ")
    buttonVUD = InlineKeyboardButton(text="VUD", callback_data="button_VUD")
    buttonVISP = InlineKeyboardButton(text="VISP", callback_data="button_VISP")
    def parbaude_vai_ir_grozs(klase):
      if 'DA'   in klase:   keyboard.add(buttonDA)
      if 'UZ'   in klase:   keyboard.add(buttonUZ)
      if 'VM'   in klase:   keyboard.add(buttonVM)
      if 'DIT'  in klase:  keyboard.add(buttonDIT)
      if 'DAS'  in klase:  keyboard.add(buttonDAS)
      if 'INZ'  in klase:  keyboard.add(buttonINZ)
      if 'VUD'  in klase:  keyboard.add(buttonVUD)
      if 'VISP' in klase: keyboard.add(buttonVISP)
    if data == 'button_10': parbaude_vai_ir_grozs(klase10)
    if data == 'button_11': parbaude_vai_ir_grozs(klase11)
    if data == 'button_12': parbaude_vai_ir_grozs(klase12)
    await bot.send_message(chat_id=callback_query.message.chat.id, text="Izvēlaties savu klasi!", reply_markup=keyboard)
  elif data in burti or data in grozi: #KAD LIETOTĀJS IZVĒLĀS BEIGA KLASI
    global klasesb
    klasesb = data[7:]
    skolena_klase = numurs + '.' + klasesb
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(chat_id=callback_query.message.chat.id, text=f"Paldies par izvēli! Kopš šī brīža jums tiks sūtītas <b>{skolena_klase}</b> klases izmaiņas!", parse_mode='html')
    await bot.send_message(chat_id=callback_query.message.chat.id, text="🥳")
    print(callback_query.message.chat.id, "-", skolena_klase)
    if(not db.subscriber_exists(callback_query.message.chat.id)):
      db.add_subscriber(callback_query.message.chat.id, skolena_klase, True)
    else:
      db.update_class(callback_query.message.chat.id, skolena_klase)
      db.update_status(callback_query.message.chat.id, True)
  if data == 'button_priecaties':
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(chat_id=callback_query.message.chat.id, text="🥳")
    await asyncio.sleep(5)
  if data == 'button_raudat':
    await bot.answer_callback_query(callback_query.id)
    await bot.send_message(chat_id=callback_query.message.chat.id, text="😢")
    await asyncio.sleep(5)
async def scheduled():
  ritdiena = datetime.datetime.today() + datetime.timedelta(days=1)
  ritdiena = ritdiena.strftime("%d.%m.%Y")
  izmainas = sutisana.jaunas_izmainas(ritdiena)
  if(izmainas):
    str = ''
    def convertTuple(tup):
      str = ''
      for item in tup:
        str = str + item
      return str
    ids_tuple = db.get_subscriptions()
    klases_tuple = db.get_class()
    ids = []
    klases = []
    s=0
    for item in ids_tuple:
      print(f'ids_tuple[{s}]:    {ids_tuple[s]}')
      temp = convertTuple(ids_tuple[s]) #temporary variable to append new id
      ids.append(temp)
      print(f'ids[{s}]:          {ids[s]}')
      print(f'klases_tuple[{s}]: {klases_tuple[s]}')
      temp = convertTuple(klases_tuple[s]) #temporary variable to append new class
      klases.append(temp)
      print(f'klases[{s}]:       {klases[s]}')
      s=s+1
    n=0
    for k in ids:
      if re.search(klases[n], izmainas.upper()):
        manas_izmainas = sutisana.izmainu_info(ritdiena, klases[n])
        #print(type(manas_izmainas))
        manas_izmainas = manas_izmainas.replace("\\xa0", "\n").replace("['", "").replace("']", "").replace("', '", "")
        await bot.send_message(ids[n], text=f"{manas_izmainas}", parse_mode='html')
      else:
        keyboard = InlineKeyboardMarkup()
        button_raudat = InlineKeyboardButton(text="Raudāt😢", callback_data="button_raudat")
        button_priecaties = InlineKeyboardButton(text="Priecāties🥳", callback_data="button_priecaties")
        keyboard.add(button_priecaties, button_raudat)
        await bot.send_message(ids[n], text="Jums nav izmaiņu!", reply_markup=keyboard)
      n+=1

async def on_startup():
  while True:
    now = datetime.datetime.now()
    if now.hour == 18 and now.minute == 0:
      await scheduled()
      print("await asyncio.sleep(60)")
      await asyncio.sleep(60)
    else:
      print("await asyncio.sleep(10)")
      await asyncio.sleep(10)

if __name__ == '__main__':
  loop = asyncio.get_event_loop()
  loop.create_task(on_startup())
  executor.start_polling(dp, loop=asyncio.get_event_loop(), skip_updates=True)