import re
from re import search
#import os.path
import requests
from bs4 import BeautifulSoup as BS
#from urllib.parse import urlparse

class sutisana:
  def jaunas_izmainas(ritdiena):
    url = 'https://www.r64vsk.lv'
    response = requests.get(url)
    html = BS(response.content, 'html.parser')
    
    izmainu_saraksts = html.find("div", "r64-events", "p")
    if re.search(ritdiena, str(izmainu_saraksts)): izmainas = str(izmainu_saraksts)
    else: izmainas = ""
    return izmainas
  
  def izmainu_info(ritdiena, manaklase):
    url = 'https://www.r64vsk.lv'
    response = requests.get(url)
    zupa = BS(response.content, 'html.parser')
    izmainu_saraksts = zupa.find("div", "r64-events", "p")
    izmainu_saraksts = str(izmainu_saraksts).replace('<div class="r64-events">', "").replace('<p>', "").replace('</div>', "").replace("</p>", "").replace('<br/>', "\n")
    def formatesana(n, k, izmainu_saraksts):
      if k == 0:
        izmainu_saraksts[k] = izmainu_saraksts[k].replace("sk.", "sk. ").replace(".", ". ").replace("-", "–").replace(". _", "._").replace("  ", " ")
      else:
        izmainu_saraksts[k] = izmainu_saraksts[k][:4] + izmainu_saraksts[k][4:].replace(".", ". ")
        if izmainu_saraksts[k].startswith("1"):
          izmainu_saraksts[k] = '<b>' + izmainu_saraksts[k][:n].upper() + '</b>' + izmainu_saraksts[k][n:]
        elif izmainu_saraksts[k].startswith(("5", "6", "7", "8", "9")): izmainu_saraksts[k] = '<b>' + izmainu_saraksts[k][:3].upper() + '</b>' + izmainu_saraksts[k][3:]
        if izmainu_saraksts[k][:n+4].endswith("-") and not izmainu_saraksts[k][:n+5].endswith(" "): izmainu_saraksts[k] = izmainu_saraksts[k][:n+4] + " " + izmainu_saraksts[k][n+4:]
        izmainu_saraksts[k] = izmainu_saraksts[k].replace("  ", " ").replace(". -", ". – ").replace("kab. ", "kab.").replace(". ,", ".,").replace(",", ", ").replace(" (", "(").replace(".(", ". (").replace("L. p. vēsture", "Latvijas un pasaules vēsture ").replace(".st.brīva", ". stunda ir brīva").replace(" -", ": ").replace("  ", " ").replace("  ", " ")
    if search(manaklase, izmainu_saraksts.upper()) and search(ritdiena, izmainu_saraksts):
      izmainu_saraksts = izmainu_saraksts.splitlines()
      izmainu_saraksts = [i for i in izmainu_saraksts if i]
      while izmainu_saraksts[0].startswith(" "):
        izmainu_saraksts[0] = izmainu_saraksts[0][1:]
      if izmainu_saraksts[0].startswith("O"): dg = 8
      elif izmainu_saraksts[0].startswith(("Pirm", "T")): dg = 9
      elif izmainu_saraksts[0].startswith("C"): dg = 10
      elif izmainu_saraksts[0].startswith("Piekt"): dg = 11
      if izmainu_saraksts[0].startswith(("Pirm", "O", "T", "C", "Piekt")):
        formatesana(dg, 0, izmainu_saraksts)
      k = 0
      for i in izmainu_saraksts:
        while izmainu_saraksts[k].startswith(" "):
          izmainu_saraksts[k] = izmainu_saraksts[k][1:]
        if re.search(manaklase, izmainu_saraksts[k].upper()) or re.search(ritdiena, izmainu_saraksts[k]):
          if izmainu_saraksts[k].upper().startswith(manaklase):
            formatesana(len(manaklase), k, izmainu_saraksts)
          elif k!=0: izmainu_saraksts[k] = izmainu_saraksts[k].replace(". -", ". – ").replace(".", ". ").replace(".", ". ").replace("  ", " ")
        else: izmainu_saraksts[k] = ""
        k+=1
      izmainu_saraksts = [i for i in izmainu_saraksts if i]
    
    izmainas = str(izmainu_saraksts)
    return izmainas